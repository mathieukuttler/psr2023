# gruppe C
# 817928, 787490, 821198
# Übung 2: Aufgabe 5


integer_var = 42
float_var = 47.11
string_var = 'hello world'
bool_var = True
list_var = ['a','b','c'] 
tuple_var = (1,22)
result = integer_var + float_var
end_of_list = list_var[-1]

# Prints zur Überprüfung:
print(integer_var, float_var, string_var, bool_var)
print(list_var)
print(tuple_var)
print(result)
print(end_of_list)
