# gruppe C
# 817928, 787490, 821198
# Übung 2: Aufgabe 2


satz1 = "Golm ist ein schoenes Fleckchen Erde."

a = satz1[1]
b = satz1[:3]
c = satz1[0:-1:5]
d = satz1[:4][::-1]
e = satz1[::-1]

# printouts für die Überprüfung:
print(a)
print(b)
print(c)
print(d)
print(e)
