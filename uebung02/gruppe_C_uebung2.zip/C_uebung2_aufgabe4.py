# gruppe C
# 817928, 787490, 821198
# Übung 2: Aufgabe 4


ein_tupel = (1, 2) 
zweites_tupel = (3,)
# dieses Print wird in der Aufgabe verlangt:
print(ein_tupel + zweites_tupel)
