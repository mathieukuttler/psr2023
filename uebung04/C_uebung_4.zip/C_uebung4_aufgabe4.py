import random

# Zufallszahl erzeugen
zufallszahl = random.randint(0, 1)

# Zuweisen der Münzseite:
if zufallszahl == 0:
    print('Kopf')
else:
    print('Zahl')

