# gruppe C
# 817928, 787490, 821198
# Übung 1: Aufgabe 2

result_1 = (25 / 3 * 4)
result_2 = ((33 - 5) / 7 + 2) / 6
result_3 = (3 * 7 + 4) / 10
result_4 = ((5 + 63) * 5 - 20) / 8
result_5 = (5 * 2 - 15) / 0.5 + 10
