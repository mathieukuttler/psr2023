# gruppe C
# 817928, 787490, 821198
# Übung 1: Aufgabe 4

print('Wie heisst Du?')
username = input()
print(username) # echo
print('Hallo ' + username + '.' )
