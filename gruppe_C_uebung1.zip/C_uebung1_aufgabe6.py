# gruppe C
# 817928, 787490, 821198
# Übung 1: Aufgabe 6

print('Bitte geben Sie eine ganze Zahl ein.')
zahl1 = int(input())

print('Bitte geben Sie noch eine ganze Zahl ein.')
zahl2 = int(input())

check = zahl1 == zahl2
print(check)

addition = zahl1 + zahl2
print(addition)

multiplication = zahl1 * zahl2
print(multiplication)

substraction = zahl1 - zahl2
print(substraction)
