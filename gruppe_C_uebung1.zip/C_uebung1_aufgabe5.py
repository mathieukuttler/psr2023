# gruppe C
# 817928, 787490, 821198
# Übung 1: Aufgabe 5

print('Gib bitte ein Wort ein.')
string1 = input()
print('Gib bitte ein zweites Wort ein.')
string2 = input()

aufgabe_5_2 = string2 + string2 + string2
print(aufgabe_5_2)

aufgabe_5_3 = string1 + string2
print(aufgabe_5_3)

stars = '***'
aufgabe_5_4 = stars + string1 + stars + string2 + stars
print(aufgabe_5_4)

