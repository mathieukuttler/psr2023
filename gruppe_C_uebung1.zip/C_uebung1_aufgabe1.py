# gruppe C
# 817928, 787490, 821198
# Übung 1: Aufgabe 1

result_1 = (2 + 3) * 5 - 7 == 18
result_2 = (10 + 1) * (6 + 5) == 121
result_3 = (9 / 3 + 5 - 8) - 5 == -5
