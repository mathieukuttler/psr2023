# gruppe C
# 817928, 787490, 821198
# Übung 1: Aufgabe 3

name = "Wladimir"
fach = "Sport"
fachsemester = 2
lieblingskurs = "Trainingstheorie"
lieblingsesen = "Pizza"

print('Hallo, ich heiße ' + name + '.')
print('Ich studiere ' + fach + ' im ' + str(fachsemester) + '. Semester.') 
print('Mein Lieblingskurs ist ' + lieblingskurs + '.')
print('Mein Lieblingsessen ist ' + lieblingsesen + '.')
